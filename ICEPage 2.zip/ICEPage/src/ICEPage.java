
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author katiecole
 */
public class ICEPage extends javax.swing.JFrame {

    /**
     * Creates new form ICEPage
     */
    public ICEPage() {
        initComponents();
        updateEmergContactList();
        updateDocContactList();
        initList1();
        initList2();
    }
    String contactName;
    Connection conn1 = null;
    Connection conn2 = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    DefaultListCellRenderer centerRender = new DefaultListCellRenderer();
    DefaultListModel ECL = new DefaultListModel();
    DefaultListModel DCL = new DefaultListModel();
    DefaultListModel ECIL = new DefaultListModel();
    DefaultListModel DCIL = new DefaultListModel();
    
    public static Connection ConnectDB()
    {
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection conn1 = DriverManager.getConnection("jdbc:sqlite:/Users/katherinecole 1/NetBeansProjects/ICEPage/src/Contacts.db");
            return conn1;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public static Connection ConnectDB2()
    {
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection conn2 = DriverManager.getConnection("jdbc:sqlite:/Users/katherinecole 1/NetBeansProjects/ICEPage/src/Doctors.db");
            return conn2;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public void updateEmergContactList()
    {
        conn1 = ICEPage.ConnectDB();
        
        if (conn1 != null)
        {
            String sql = "Select Name FROM Contacts;";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    ECL.addElement(rs.getString("Name"));
  
                }
                emergContactList.setModel(ECL);
                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void updateDocContactList()
    {
        conn2 = ICEPage.ConnectDB2();
        
        if (conn2 != null)
        {
            String sql = "Select * FROM Doctors;";
            
            try
            {
                pst = conn2.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    DCL.addElement(rs.getString("Name"));
  
                }
                docContactList.setModel(DCL);
                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    private void initList1()
    {

        conn1 = ICEPage.ConnectDB();
        stylizeList();
        emergContactList.setModel(ECL);
    
    }
    private void initList2()
    {

        conn2 = ICEPage.ConnectDB();
        stylizeList();
        docContactList.setModel(DCL);
        
    }
    
    private void stylizeList()
    {
                
        
        centerRender.setHorizontalAlignment(JLabel.CENTER);
        centerRender.setHorizontalTextPosition(JLabel.CENTER);
        centerRender.setVerticalAlignment(JLabel.CENTER);
        centerRender.setBorder(BorderFactory.createBevelBorder(1));
        
        
        emergContactList.setCellRenderer(centerRender);
        docContactList.setCellRenderer(centerRender);
        
    }
    
    public void getEmergContactInfo(){
        conn1 = ICEPage.ConnectDB();
        
        
        if (conn1 != null)
        {
            contactName = emergContactList.getSelectedValue();
            String sql = "Select * FROM Contacts WHERE Name = '" + contactName + "';";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    ECIL.addElement("Contact Name: " + rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(!address.equals("null")){
                    ECIL.addElement("Address: " + rs.getString("Address"));
                    }
                    
                    ECIL.addElement("Phone Number: " + rs.getString("Phone Number"));
                    
                    ECIL.addElement("Relationship: " + rs.getString("Relationship"));
  
                }
                
                pst.close();
                rs.close();
                emergContactInfoList.setModel(ECIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    public void getDocContactInfo(){
        conn2 = ICEPage.ConnectDB2();
        
        
        if (conn2 != null)
        {
            contactName = docContactList.getSelectedValue();
            String sql = "Select * FROM Doctors WHERE Name = '" + contactName + "';";
            
            try
            {
                pst = conn2.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    DCIL.addElement("Doctor's Name: " + rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(!address.equals("null")){
                    DCIL.addElement("Address: " + rs.getString("Address"));
                    }
                    
                    DCIL.addElement("Phone Number: " + rs.getString("Phone Number"));
                    
                    DCIL.addElement("Specialty: " + rs.getString("Specialty"));
  
                }
                
                pst.close();
                rs.close();
                docContactInfoList.setModel(DCIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void editEmergContactInfo(){
        conn1 = ICEPage.ConnectDB();
        
        if (conn1 != null)
        {
            contactName = emergContactList.getSelectedValue();
            String sql = "Select * FROM Contacts WHERE Name = '" + contactName + "';";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    contactNameEdit.setText(rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(address.equals("null") == true){
                    contactAddressEdit.setText("");
                    }
                    else{
                        contactAddressEdit.setText(rs.getString("Address"));
                    }
                     
                    contactPhoneEdit.setText(rs.getString("Phone Number")); 
                    
                }
                
                pst.close();
                rs.close();
                emergContactInfoList.setModel(ECIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ICEPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ICEPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ICEPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ICEPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ICEPage().setVisible(true);
            }
        });
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        contactListPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        emergContactList = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        docContactList = new javax.swing.JList<>();
        addContactBttn = new javax.swing.JButton();
        titlePage = new javax.swing.JLabel();
        addDoctorBttn = new javax.swing.JButton();
        emergContactInfoPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        emergContactInfoList = new javax.swing.JList<>();
        EmerContactInfoBackBttn = new javax.swing.JButton();
        EmergContactEditBttn = new javax.swing.JButton();
        docContactInfoPanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        docContactInfoList = new javax.swing.JList<>();
        DocContactInfoBackBttn1 = new javax.swing.JButton();
        DocContactEditBttn1 = new javax.swing.JButton();
        editEmergContactPanel = new javax.swing.JPanel();
        EmerContactInfoBackBttn1 = new javax.swing.JButton();
        EmergContactEditBttn1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        contactNameEdit = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        contactAddressEdit = new javax.swing.JTextField();
        contactPhoneEdit = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        contactRelationsEdit = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(510, 800));
        setPreferredSize(new java.awt.Dimension(510, 800));

        jPanel1.setSize(new java.awt.Dimension(510, 800));
        jPanel1.setLayout(new java.awt.CardLayout());

        contactListPanel.setBackground(new java.awt.Color(255, 232, 214));
        contactListPanel.setMaximumSize(new java.awt.Dimension(510, 800));
        contactListPanel.setPreferredSize(new java.awt.Dimension(510, 800));
        contactListPanel.setSize(new java.awt.Dimension(510, 800));

        emergContactList.setBackground(new java.awt.Color(107, 112, 92));
        emergContactList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        emergContactList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emergContactListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(emergContactList);

        docContactList.setBackground(new java.awt.Color(107, 112, 92));
        docContactList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        docContactList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                docContactListMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(docContactList);

        addContactBttn.setText("Add New Contact");
        addContactBttn.setToolTipText("");
        addContactBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addContactBttnActionPerformed(evt);
            }
        });

        titlePage.setText("IN CASE OF EMERGENCIES");

        addDoctorBttn.setText("Add Doctor");
        addDoctorBttn.setActionCommand("Add New Doctor");

        javax.swing.GroupLayout contactListPanelLayout = new javax.swing.GroupLayout(contactListPanel);
        contactListPanel.setLayout(contactListPanelLayout);
        contactListPanelLayout.setHorizontalGroup(
            contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactListPanelLayout.createSequentialGroup()
                .addGap(161, 161, 161)
                .addGroup(contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contactListPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(addDoctorBttn, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(contactListPanelLayout.createSequentialGroup()
                            .addComponent(addContactBttn)
                            .addGap(23, 23, 23)))
                    .addComponent(titlePage, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(313, Short.MAX_VALUE))
        );
        contactListPanelLayout.setVerticalGroup(
            contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactListPanelLayout.createSequentialGroup()
                .addComponent(titlePage, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addContactBttn)
                .addGap(48, 48, 48)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addDoctorBttn)
                .addContainerGap(254, Short.MAX_VALUE))
        );

        jPanel1.add(contactListPanel, "card2");

        emergContactInfoPanel.setBackground(new java.awt.Color(255, 232, 214));

        jScrollPane3.setMaximumSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setMinimumSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setPreferredSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setSize(new java.awt.Dimension(275, 300));

        emergContactInfoList.setBackground(new java.awt.Color(107, 112, 92));
        emergContactInfoList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        emergContactInfoList.setAutoscrolls(false);
        emergContactInfoList.setMaximumSize(new java.awt.Dimension(275, 300));
        emergContactInfoList.setMinimumSize(new java.awt.Dimension(275, 300));
        emergContactInfoList.setPreferredSize(new java.awt.Dimension(275, 300));
        emergContactInfoList.setSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setViewportView(emergContactInfoList);

        EmerContactInfoBackBttn.setText("Back");
        EmerContactInfoBackBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmerContactInfoBackBttnActionPerformed(evt);
            }
        });

        EmergContactEditBttn.setText("Edit");
        EmergContactEditBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmergContactEditBttnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout emergContactInfoPanelLayout = new javax.swing.GroupLayout(emergContactInfoPanel);
        emergContactInfoPanel.setLayout(emergContactInfoPanelLayout);
        emergContactInfoPanelLayout.setHorizontalGroup(
            emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                .addGroup(emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(EmerContactInfoBackBttn)
                        .addGap(166, 166, 166)
                        .addComponent(EmergContactEditBttn))
                    .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(270, Short.MAX_VALUE))
        );
        emergContactInfoPanelLayout.setVerticalGroup(
            emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmerContactInfoBackBttn)
                    .addComponent(EmergContactEditBttn))
                .addContainerGap(480, Short.MAX_VALUE))
        );

        jPanel1.add(emergContactInfoPanel, "card3");

        docContactInfoPanel.setBackground(new java.awt.Color(255, 232, 214));

        jScrollPane4.setBackground(new java.awt.Color(107, 112, 92));
        jScrollPane4.setForeground(new java.awt.Color(107, 112, 92));
        jScrollPane4.setPreferredSize(new java.awt.Dimension(275, 300));

        docContactInfoList.setBackground(new java.awt.Color(107, 112, 92));
        docContactInfoList.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        docContactInfoList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        docContactInfoList.setPreferredSize(new java.awt.Dimension(275, 300));
        jScrollPane4.setViewportView(docContactInfoList);

        DocContactInfoBackBttn1.setText("Back");
        DocContactInfoBackBttn1.setToolTipText("");
        DocContactInfoBackBttn1.setActionCommand("Back");
        DocContactInfoBackBttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DocContactInfoBackBttn1ActionPerformed(evt);
            }
        });

        DocContactEditBttn1.setText("Edit");
        DocContactEditBttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DocContactEditBttn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout docContactInfoPanelLayout = new javax.swing.GroupLayout(docContactInfoPanel);
        docContactInfoPanel.setLayout(docContactInfoPanelLayout);
        docContactInfoPanelLayout.setHorizontalGroup(
            docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                .addGroup(docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(DocContactInfoBackBttn1)
                        .addGap(73, 73, 73)
                        .addComponent(DocContactEditBttn1))
                    .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(326, Short.MAX_VALUE))
        );
        docContactInfoPanelLayout.setVerticalGroup(
            docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                .addGap(266, 266, 266)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DocContactInfoBackBttn1)
                    .addComponent(DocContactEditBttn1))
                .addContainerGap(340, Short.MAX_VALUE))
        );

        jPanel1.add(docContactInfoPanel, "card3");

        editEmergContactPanel.setBackground(new java.awt.Color(255, 232, 214));

        EmerContactInfoBackBttn1.setText("Back");
        EmerContactInfoBackBttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmerContactInfoBackBttn1ActionPerformed(evt);
            }
        });

        EmergContactEditBttn1.setText("Edit");
        EmergContactEditBttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmergContactEditBttn1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Emergency Contact:");

        contactNameEdit.setText("jTextField1");

        jLabel2.setText("Address:");

        contactAddressEdit.setText("jTextField2");

        contactPhoneEdit.setText("jTextField3");

        jLabel3.setText("Phone Number:");

        jLabel4.setText("Relationship:");
        jLabel4.setToolTipText("");

        contactRelationsEdit.setText("jTextField4");

        javax.swing.GroupLayout editEmergContactPanelLayout = new javax.swing.GroupLayout(editEmergContactPanel);
        editEmergContactPanel.setLayout(editEmergContactPanelLayout);
        editEmergContactPanelLayout.setHorizontalGroup(
            editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(EmerContactInfoBackBttn1)
                        .addGap(95, 95, 95)
                        .addComponent(EmergContactEditBttn1))
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(27, 27, 27)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(contactAddressEdit, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                            .addComponent(contactPhoneEdit)
                            .addComponent(contactRelationsEdit)
                            .addComponent(contactNameEdit))))
                .addContainerGap(111, Short.MAX_VALUE))
        );
        editEmergContactPanelLayout.setVerticalGroup(
            editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(contactNameEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(contactAddressEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(contactPhoneEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(contactRelationsEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 385, Short.MAX_VALUE)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmerContactInfoBackBttn1)
                    .addComponent(EmergContactEditBttn1))
                .addGap(26, 26, 26))
        );

        jPanel1.add(editEmergContactPanel, "card3");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addContactBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addContactBttnActionPerformed
           // TODO add your handling code here:
    }//GEN-LAST:event_addContactBttnActionPerformed

    private void docContactListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_docContactListMouseClicked
        // TODO add your handling code here:
        if(evt.getClickCount() == 2 && evt.getButton() == MouseEvent.BUTTON1 && evt.getButton() != MouseEvent.BUTTON2){
            contactListPanel.setVisible(false);
            docContactInfoPanel.setVisible(true);
            getDocContactInfo();
        }
    }//GEN-LAST:event_docContactListMouseClicked

    private void emergContactListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emergContactListMouseClicked
         if(evt.getClickCount() == 2 && evt.getButton() == MouseEvent.BUTTON1 && evt.getButton() != MouseEvent.BUTTON2){
            contactListPanel.setVisible(false);
            emergContactInfoPanel.setVisible(true);
            getEmergContactInfo();
        }
    }//GEN-LAST:event_emergContactListMouseClicked

    private void DocContactInfoBackBttn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DocContactInfoBackBttn1ActionPerformed
        // TODO add your handling code here:
        docContactInfoPanel.setVisible(false);
        DCIL.removeAllElements();
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_DocContactInfoBackBttn1ActionPerformed

    private void DocContactEditBttn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DocContactEditBttn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DocContactEditBttn1ActionPerformed

    private void EmerContactInfoBackBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmerContactInfoBackBttnActionPerformed
        // TODO add your handling code here:
        emergContactInfoPanel.setVisible(false);
        ECIL.removeAllElements();
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_EmerContactInfoBackBttnActionPerformed

    private void EmergContactEditBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmergContactEditBttnActionPerformed
        // TODO add your handling code here:
        emergContactInfoPanel.setVisible(false);
        
        editEmergContactPanel.setVisible(true);
        try{
        editEmergContactInfo();
                }catch(Exception e){
                    
                }
    }//GEN-LAST:event_EmergContactEditBttnActionPerformed

    private void EmerContactInfoBackBttn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmerContactInfoBackBttn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmerContactInfoBackBttn1ActionPerformed

    private void EmergContactEditBttn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmergContactEditBttn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmergContactEditBttn1ActionPerformed
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DocContactEditBttn1;
    private javax.swing.JButton DocContactInfoBackBttn1;
    private javax.swing.JButton EmerContactInfoBackBttn;
    private javax.swing.JButton EmerContactInfoBackBttn1;
    private javax.swing.JButton EmergContactEditBttn;
    private javax.swing.JButton EmergContactEditBttn1;
    private javax.swing.JButton addContactBttn;
    private javax.swing.JButton addDoctorBttn;
    private javax.swing.JTextField contactAddressEdit;
    private javax.swing.JPanel contactListPanel;
    private javax.swing.JTextField contactNameEdit;
    private javax.swing.JTextField contactPhoneEdit;
    private javax.swing.JTextField contactRelationsEdit;
    private javax.swing.JList<String> docContactInfoList;
    private javax.swing.JPanel docContactInfoPanel;
    private javax.swing.JList<String> docContactList;
    private javax.swing.JPanel editEmergContactPanel;
    private javax.swing.JList<String> emergContactInfoList;
    private javax.swing.JPanel emergContactInfoPanel;
    private javax.swing.JList<String> emergContactList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel titlePage;
    // End of variables declaration//GEN-END:variables
}
